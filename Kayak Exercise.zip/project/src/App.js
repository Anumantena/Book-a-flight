import "./App.css";
import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import jsonp from "jsonp";
import axios from "axios";
import FlightList from "./components/FlightList";
import FlightDisplay from "./components/FlightDisplay";
import useDebounce from "./debounce";
import SwipeableViews from "react-swipeable-views";
import Box from "@mui/material/Box";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  console.log({ value, index });
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

function App() {
  const [search, setSearch] = useState("");
  const [inputResults, setInputResults] = useState([]);
  const [resultsFromServer, setResultsFromServer] = useState([]);

  const [flightDetails, setFlightDetails] = useState({});

  const [appView, setAppView] = useState(0);

  const parseWebsite = (data) => {
    let list = data.map((item) => {
      let site = item.site;

      if (site.startsWith("http")) {
        site = site.substr(8);
      }

      if (site.startsWith("www")) {
        site = site.substr(4);
      }

      if (site.includes("/")) {
        let index = site.indexOf("/");
        site = site.substring(0, index);
      }

      item.site = site;
      return item;
    });
    return list;
  };

  useEffect(() => {
    jsonp(
      "https://www.kayak.com/h/mobileapis/directory/airlines/homework",
      { param: "jsonp" },
      (error, data) => {
        if (error) {
          console.log(error);
        } else {
          let list = parseWebsite(data);
          axios
            .post("http://localhost:3000/flights/saveAll", {
              list,
            })
            .then(() => {
              console.log("success");
            })
            .catch((err) => {
              console.log("Error: " + JSON.stringify(err));
            });
          setResultsFromServer(list);
          // setResultsFromServer(mockServerResults)
        }
      }
    );
  }, []);

  const handleChange = (e) => {
    setSearch(e.target.value);
  };

  let debounceSearch = useDebounce(search, 500);

  const handleChangeIndex = (view, flightDetails) => {
    console.log("handleChangeIndex", view);
    setAppView(view);
    if (flightDetails) {
      setFlightDetails(flightDetails);
    }
  };

  useEffect(() => {
    if (debounceSearch) {
      axios
        .get(`http://localhost:3000/flights/${debounceSearch}`)
        .then((res) => {
          // console.log(res)
          setInputResults(res.data);
        })
        .catch((err) => {
          console.error(JSON.stringify(err));
        });
    }
  }, [debounceSearch]);

  return (
    <div className="App">
      <Navbar />
      <SwipeableViews
        axis={"x"}
        index={appView}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={appView} index={0}>
          <FlightList
            search={search}
            handleChange={handleChange}
            resultsFromServer={resultsFromServer}
            inputResults={inputResults}
            goToFlightDisplay={(view, flightDetails) =>
              handleChangeIndex(view, flightDetails)
            }
          />
        </TabPanel>
        <TabPanel value={appView} index={1}>
          <FlightDisplay
            goToFlightDisplay={(view, flightDetails) =>
              handleChangeIndex(view, flightDetails)
            }
            flightDetails={flightDetails}
          />
        </TabPanel>
      </SwipeableViews>
    </div>
  );
}
export default App;

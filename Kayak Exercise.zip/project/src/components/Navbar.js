import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import Button from '@material-ui/core/Button';
import MenuIcon from '@material-ui/icons/Menu';
// import ModalDialog from './ModalDialog';

const useStyles = makeStyles(theme => ({

    logo: {
        marginRight: theme.spacing(2),
        maxWidth: 160,
    },
}));

const Navbar = () => {
    const classes = useStyles();
    const [open, setOpen] = useState(false);

    const handleOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };


    return (
        <AppBar position="static" style={{ background: '#333333' }}>
            <Toolbar>
                {/* <IconButton
                    edge="start"
                    color="black"
                    aria-label="menu"
                    className={classes.menuButton}
                >
                    
                </IconButton> */}
                <Typography variant="h6" className={classes.title}>
                    <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI1IiBoZWlnaHQ9IjI0IiB2aWV3Qm94PSIwIDAgMTI1IDI0IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTAgMjMuOTk5OEgyMy45MzYyVjBIMFYyMy45OTk4Wk0yNS4yNjYgMjMuOTk5OEg0OS4yMDIxVjBIMjUuMjY2VjIzLjk5OThaTTc0LjQ2ODEgMjMuOTk5OEg1MC41MzE5VjBINzQuNDY4MVYyMy45OTk4Wk03NS43OTc5IDIzLjk5OThIOTkuNzM0VjBINzUuNzk3OVYyMy45OTk4Wk0xMjUgMjMuOTk5OEgxMDEuMDY0VjBIMTI1VjIzLjk5OThaIiBmaWxsPSIjRkY2OTBGIi8+CjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTAuMjg2OCAxMS41NDg2VjZINy4zNzk4OFYxOEgxMC4yODY4VjEyLjQ1MTZMMTMuMzQ4MSAxOC4wMDAxSDE2LjU1NjJMMTMuMjI2NSAxMi4wMDAxTDE2LjU1NjIgNi4wMDAwOEgxMy4zNDgxTDEwLjI4NjggMTEuNTQ4NlpNMzUuMDcyIDE2LjI3MjlMMzQuNTUxNSAxOC4wMDAxSDMxLjQ0NzVMMzUuMzk0OCA2LjAwMDFIMzkuMDkxMUw0My4wMjA2IDE4LjAwMDFIMzkuODI2OEwzOS4zMDYzIDE2LjI3MjlIMzUuMDcyWk0zNy4xODkxIDkuNDM2NDNMMzUuNzg5NSAxMy45MTYxSDM4LjU4ODdMMzcuMTg5MSA5LjQzNjQzWk02My45ODAzIDE4LjAwMDFINjEuMDczNlYxMi43MTA4TDU3LjE0NCA2LjAwMDA4SDYwLjYwNzFMNjIuNTQ0OCA5LjY4ODA4TDY0LjQ0NjkgNi4wMDAwOEg2Ny44NTU4TDYzLjk4MDMgMTIuNzEwOFYxOC4wMDAxWk04NS42MDM5IDE2LjI3MjlMODUuMDgzNCAxOC4wMDAxSDgxLjk3OTRMODUuOTI2NyA2LjAwMDFIODkuNjIzTDkzLjU1MjMgMTguMDAwMUg5MC4zNTg3TDg5LjgzODIgMTYuMjcyOUg4NS42MDM5Wk04Ny43MjExIDkuNDM2NDNMODYuMzIxNSAxMy45MTYxSDg5LjEyMDdMODcuNzIxMSA5LjQzNjQzWk0xMTEuMzUxIDExLjU0ODZWNkgxMDguNDQ0VjE4SDExMS4zNTFWMTIuNDUxNkwxMTQuNDEyIDE4LjAwMDFIMTE3LjYyTDExNC4yOSAxMi4wMDAxTDExNy42MiA2LjAwMDA4SDExNC40MTJMMTExLjM1MSAxMS41NDg2WiIgZmlsbD0iI0ZBRkFGQyIvPgo8L3N2Zz4K" alt="logo"></img>

                    {/* <svg class="svg-image" role="img" xmlns="http://www.w3.org/2000/svg"></svg> */}


                </Typography>

            </Toolbar>
            {/* <ModalDialog open={open} handleClose={handleClose} /> */}
        </AppBar >
    );
};

export default Navbar;
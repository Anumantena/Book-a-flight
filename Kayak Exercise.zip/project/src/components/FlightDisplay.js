import { Button, TextField, Typography } from "@mui/material";
import React, { useState } from "react";
import Card from "./Card";

// function FlightDisplay(props){

const FlightDisplay = ({ goToFlightDisplay, flightDetails }) => {
  const [status, setStatus] = useState("");
  const handleCheckFlightStatus = () => {
    console.log({ flightDetails });
    window.open(
      `https://www.kayak.com/tracker/${flightDetails.code}-${status}`,
      "_blank"
    );
    // https://www.kayak.com/tracker/AA-5579/2022-01-27
  };
  return (
    <div>
      <div className="div">
        <Button onClick={() => goToFlightDisplay(0)} variant="text">
          <span
            style={{
              color: "#f49000",
              marginRight: "5px",
            }}
          >
            {"<"}
          </span>
          Back to list
        </Button>
      </div>
      <div>
        <Card item={flightDetails} shouldAnimate={true} />
      </div>
      <Typography color="text.primary" gutterBottom>
        Check flight status
      </Typography>
      {/* <div className="div">Check flight status</div> */}
      <div>
        <TextField
          placeholder="Enter flight number..."
          onChange={(e) => setStatus(e.target.value)}
          value={status}
          size="small"
        />
        <Button
          className="btn"
          onClick={handleCheckFlightStatus}
          variant="contained"
          sx={{
            borderRadius: "80px",
            color: "white",
          }}
        >
          {" "}
          Check
        </Button>
        {/* /> */}
      </div>
    </div>
  );
};

export default FlightDisplay;

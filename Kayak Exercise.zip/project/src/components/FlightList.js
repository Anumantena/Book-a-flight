import * as React from "react";
import Card from "./Card";
import Pagination from "./Pagination";
import { TextField } from "@mui/material";

const FlightList = ({
  search,
  handleChange,
  resultsFromServer,
  inputResults,
  goToFlightDisplay,
}) => {
  const [page, setPage] = React.useState(0);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  let displayResults = search === "" ? resultsFromServer : inputResults;

  return (
    <>
      <TextField
        placeholder="Airline filter..."
        value={search}
        onChange={handleChange}
        sx={{
          mb: 2
        }}
        fullWidth
        size="small"
      />

      {displayResults
        .slice(page * 10, page * 10 + 10) // first time = [], next time as we type - [..n]
        .map((item, id) => (
          <Card
            variant=""
            key={id}
            item={item}
            goToFlightDisplay={(view) => goToFlightDisplay(view, item)}
          />
        ))}
      <Pagination
        count={displayResults.length}
        page={page}
        handleChangePage={handleChangePage}
      />
    </>
  );
};

export default FlightList;

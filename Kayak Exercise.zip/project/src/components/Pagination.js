import * as React from 'react';
import TablePagination from '@mui/material/TablePagination';

export default function TablePaginationDemo({ count, page, handleChangePage }) {

    return (
        <TablePagination
            component="div"
            count={count}
            page={page}
            onPageChange={handleChangePage}
            rowsPerPage={10}
            labelRowsPerPage=""
            SelectProps={{
                style: {
                    display: 'none'
                }
            }}
            sx={{
                display: 'flex',
                justifyContent: 'center'
            }}
        />
    );
}

import * as React from "react";

import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";

export default function BasicCard({ item, goToFlightDisplay, shouldAnimate }) {
  // console.log({ item });
  const { logoURL = '', name, phone, site } = item;
  const url = "https://www.kayak.com" + logoURL;
  return (
    <Card
      sx={{ minWidth: 275, marginBottom: 2 }}
      variant="outlined"
      onClick={() => !shouldAnimate && goToFlightDisplay(1)}
    >
      {!shouldAnimate ? (
        <CardActionArea sx={{ cursor: "default", display: "flex", justifyContent: "space-around" }}>
            <img
              src={url}
              alt=""
              className={`rotate-flight-icon ${shouldAnimate && "animate"}`}
            />
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondary"
              gutterBottom
            >
              {name}
            </Typography>
        </CardActionArea>
      ) : (
        <CardActionArea sx={{ cursor: "default", display: "flex", justifyContent: "space-around" }}>
          <div sx={{ display: "flex", flexDirection: "column" }}>
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondary"
              gutterBottom
            >
              {name}
            </Typography>
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondary"
              gutterBottom
            >
              {phone}
            </Typography>
              <a href={`//${site}`} target="_blank" rel="noreferrer" style={{color:"#f49000"}}>{site}</a>
          </div>
          <div>
            <img
              src={url}
              alt=""
              className={`rotate-flight-icon ${shouldAnimate && "animate"}`}
            />
          </div>
        </CardActionArea>
      )}
    </Card>
  );
}

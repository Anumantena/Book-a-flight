import './App.css';
import Navbar from './components/navbar';

export default function Details(){

return (
    <div>
        <div>
            <Navbar />
        </div>
        <div>
            <h2>check flight status</h2>
            <input type="search" /><button>check</button>
        </div>
      

    </div>
)

}
import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import Tab from './Tab.js';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

export default function BasicModal(props) {
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    return (
        <div>
            <Button onClick={handleOpen}>Open modal</Button>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <Typography id="modal-modal-title" variant="h6" component="h2">
                       Flight Tracker
                    </Typography>
                    <Tab index={0}>
                    <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                       <input type ="text" placeholder="Airline"></input>
                       <input type="text" placeholder="Flight Number"></input>
                       <input type="date"></input>
                       <button className="btn">Track Flight</button>
                    </Typography>
                    </Tab>
                    <Tab index={1}>
                        <Typography>
                            <input type="text" Placeholder="Airport" required/>
                            <input type="text" Placeholder="Airline" required/>

                        </Typography>
                    </Tab>
                </Box>
            </Modal>
        </div>
    );
}

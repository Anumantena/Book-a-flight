import * as React from 'react';

import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';

export default function BasicCard(props) {
  const url = "https://www.kayak.com" + props.img_src;
  return (
    <Card sx={{ minWidth: 275, marginBottom: 2 }} variant="outlined" onClick={() => props.goToFlightDisplay(1)}>
      <CardActionArea sx={{ cursor: 'default', display: "flex" }}>
        <span><img src={url} alt="" /></span>
        <div>
        <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
          {props.title}
        </Typography>
        </div>
      </CardActionArea>
    </Card>
  );
}

import Card from './Card';
import Pagination from './Pagination';

const FlightList = ({ search, handleChange, resultsFromServer, inputResults, goToFlightDisplay}) => {
    return (
        <>
        <div>
        <input
          type="text"
          className="search"
          placeholder='Airline filter...'
          value={search}
          onChange={handleChange}
        />
      </div>

      <div style={{
        margin: '20px'
      }}>
        {
          (search === ''
          ?
          resultsFromServer
          :
          inputResults) // first time = [], next time as we type - [..n]
          .map((item, id) => (
            <Card variant=""
              key={id}
              title={item.name}
              img_src={item.logoURL}
              phone={item.phone}
              website={item.site}
              goToFlightDisplay={goToFlightDisplay}
            />
  
          ))
        }
        <Pagination></Pagination>
      </div>
        </>
    )
}

export default FlightList;
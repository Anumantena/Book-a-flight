import Card from './Card';
import Modal from './Modal';

// function FlightDisplay(props){

const FlightDisplay = ({ goToFlightDisplay}) => {
    return (
        <div>
            <div className="div">{'<'} <button onClick={() => goToFlightDisplay(0)}>Back to list</button></div>
            <div>
                <Card
                // title={props.name}
                // img_src={props.logoURL}
                // phone={props.phone}
                // website={props.site} 
                />
            </div>
            <div className="div">Check flight status</div>
            <div>
                <span><input type ="search" className="fsearch"
                placeholder = "Enter flight number..."
                />
                {/* <Modal */}
                <button className="btn">Check</button></span>
            {/* /> */}
        
            </div>
        </div>
    )
}

export default FlightDisplay;
